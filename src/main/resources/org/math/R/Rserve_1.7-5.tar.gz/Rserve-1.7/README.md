Linux & OSX [![Build Status](https://travis-ci.org/yannrichet/Rserve-1.7.png)](https://travis-ci.org/yannrichet/Rserve-1.7)
Windows [![AppVeyor Build Status](https://ci.appveyor.com/api/projects/status/github/DiceKrigingClub/rserve-1-7-wc3jp?branch=master&svg=true)](https://ci.appveyor.com/project/DiceKrigingClub/rserve-1-7-wc3jp)

# Rserve-1.7

This repository is a fork of regular Rserve-1.7 sources (available at https://github.com/s-u/Rserve).

It contains automated deployement form Travis & Appveyor, to build binary Rserve packages for Windows, Linux, OSX in R stable release:

  * Windows: https://github.com/yannrichet/Rserve-1.7/releases/download/windows/Rserve_1.7-5.zip
  * Linux: https://github.com/yannrichet/Rserve-1.7/releases/download/linux/Rserve_1.7-5.tar.gz
  * OSX: https://github.com/yannrichet/Rserve-1.7/releases/download/osx/Rserve_1.7-5.tgz

